package analise;

import java.util.*;

import javax.swing.JOptionPane;

import tabela.Categoria;
import tabela.TabelaSimbolos;
import tabela.Token;

public class AnaliseSemantica {
	private static int nivel = 0;
	
	//private static Map<Integer, List<TabelaSimbolos>> tabelaSimbolos = new HashMap<>();
	private static List<TabelaSimbolos> list = new ArrayList<TabelaSimbolos>();
	//lista tempor�ria respons�vel pela dele��o
	private static List<String> listTempProc = new ArrayList<String>();
	
	public static int getNivel() {
        return nivel;
    }

    public static int adicionaNivel() {
        return nivel++;
    }

    public static int removeNivel() {
        return nivel--;
    }
    
    //met�do para inserir tokens caso n�o tenham sido declarados
	@SuppressWarnings("unchecked")
	public static boolean insere(String nome, Categoria categoria, String tipo) {
		
		if(confereNivel(nome, getNivel())) {
			JOptionPane.showMessageDialog(null, "Identificador ja declarado: "+ nome);
			return true;
		}
		//armazena tokens em uma lista caso os mesmos pertencem a uma procedure, para futuramente exclui-los com o m�todo delecao
		if(getNivel() == 1) {
			listTempProc.add(nome);
		}
		
		TabelaSimbolos ts = new TabelaSimbolos(nome, categoria, tipo, getNivel());
		list.add(ts);
		//tabelaSimbolos.put(nivel, list);
		return false;
	}

	//busca tokens existentes, trabalhando com parametros e atribui��es
    public static boolean busca(Token temp, Token a) {
    	int cont1 = 0;
    	int cont2 = 0;
    	boolean isNum = false;
    	boolean verificaIdentificador = false;
    	boolean verificaProcedure = false;
    	boolean aux = false;
    	
    	if(temp == null) {
    		verificaProcedure = true;
    	}
    	if(a == null) {
    		verificaIdentificador = true;
    	}
    	if(!verificaIdentificador && a.getCodigo() == 26) {
    		isNum = true;
    	}
    	for (int i = 0; i < list.size(); i++) {
    		if(verificaProcedure) {
    			if(a.getPalavra().equals(list.get(i).getNomeIdentificador())) {
    				return false;
    			}
    		} else {


        		if(temp.getPalavra().equals(list.get(i).getNomeIdentificador())) {
        			if(verificaIdentificador) {
            			if(getNivel() == list.get(i).getNivel()) {
            				if(list.get(i).getTipo().equals("INTEGER")) {
                				return false;	
            				}
            			}
            		}
    				cont1 = i;
    			}
    			if(!verificaIdentificador && !isNum && a.getPalavra().equals(list.get(i).getNomeIdentificador())) {
    				cont2 = i;
    				aux = true;
    			}
    		}
		}
    	if(verificaProcedure) {
    		JOptionPane.showMessageDialog(null, "Procedure invalida -> "+ a.getPalavra());
    		return true;
    	}
    	if(verificaIdentificador) {
    		JOptionPane.showMessageDialog(null, "Variavel invalida -> "+ temp.getPalavra());
    		return true;
    	}
		//verificando parametro call
    	if(aux && !verificaIdentificador && !isNum && list.get(cont1).getTipo().equals(list.get(cont2).getTipo())) {
    		return false;
    	}
    	if(isNum) {
    		if(list.get(cont1).getTipo().equals("INTEGER")) {
    			return false;
    		}
    	}	
    	JOptionPane.showMessageDialog(null, "Parametro invalido para a procedure: "+ temp.getPalavra());
    	AnaliseSemantica.limpar();
		return true;
    }
    
    //deleta tokens que declarados dentro de uma procedure
    public static void delecao() {
    	for (int i = 0; i < listTempProc.size(); i++) {
    		for(int j = 0; j < list.size(); j++) {
        		if(listTempProc.get(i).equals(list.get(j).getNomeIdentificador())) {
        			if(list.get(j).getNivel() == 1) {
        				list.remove(j);
        				j = list.size();
        			}
        		}
    		}
    	}
    }
	
    //m�todo que auxilia a inser��o, checando niveis de tokens
    //caso um token X seja declarado no mesmo nivel de um outro token de mesmo nome
    //ent�o gera um erro de declara��o
	private static boolean confereNivel(String nome, int nivel) {
		for (int i = 0; i < list.size(); i++) {
			if(nome.equals(list.get(i).getNomeIdentificador())) {
				if(nivel == list.get(i).getNivel()) {
					//System.out.println("INSERIR -> "+ nome +"\tNivel -> "+ nivel);
					//System.out.println("LISTADO -> "+ list.get(i).getNomeIdentificador() +"\tNivel -> "+ list.get(i).getNivel());
					return true;
				}
			}
		}
		return false;
	}
	
	//m�todo que lista tokens inseridos, apenas para testes de desenvolvimento
	public static void listar() {
		System.out.println("INSERIDO -> ");
		for (int i = 0; i < list.size(); i++) {
			System.out.println("Nome: "+ list.get(i).getNomeIdentificador());
			System.out.println("Categoria: "+ list.get(i).getCategoria());
			System.out.println("Tipo: "+ list.get(i).getTipo());
			System.out.println("Nivel: "+ list.get(i).getNivel());
			System.out.println("");
		}
	}

	//limpa lista de tokens para poder trabalhar em uma pr�xima execu��o
	public static void limpar() {
		list.clear();
		listTempProc.clear();
		//tabelaSimbolos.clear();
		nivel = 0;
	}
}
