package analise;

import java.util.HashMap;
import java.util.Map;
import java.util.Stack;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import tabela.TokensLexico;
import tabela.Token;

public class AnalisadorLexico {
	
	int codigo;
	int numLiteral;
	
	String literal = "";
	
	boolean caracterVazio = false;
	boolean avaliarProximoCaracter = false;
	boolean caracterDuplo = false;
	boolean semFim = false;

	Map<String,Integer> mapToken;
	Stack<Token> pilha = new Stack<Token>();

	public Stack<Token> separaLetra(String[] texto, DefaultTableModel dadosTabela) {
		mapToken = new HashMap<String,Integer>();
		
		TokensLexico tokensLexico = new TokensLexico();
		String palavra = "";
		boolean caracterLetra = true;
		boolean ultimoCaracterLetra = true;

		for(int i=0; i<texto.length; i++) {
			//sendo o caracter atual "-", e o pr�ximo caracter for um n�mero,
			//ent�o o software estar� lidando com um n�mero negativo
			if(texto[i].equals("-")) {
				if(numero(texto[i+1])) {
					continue;
				}
			}
			
			//verifica se caracter � um numero
			if(numero(texto[i])) {
				boolean variavelInvalida = false;
				//caracter anterior � um delimitador
				if(delimitador(texto[i-1])) {
					palavra = texto[i];
					if(texto[i-1].equals("-")) {
						palavra = texto[i-1];
						palavra += texto[i];
					}
					int cont = 0;
					for(int j=i+1; j<texto.length; j++) {
						if(numero(texto[j])) {
							palavra += texto[j];
						} 
						else if(delimitador(texto[j])){
							cont++;
							break;
						} else {
							dadosTabela.setNumRows(0);
							JOptionPane.showMessageDialog(null, "Vari�vel Inv�lida");
							return (pilha = null);
							//variavelInvalida = true;
							//cont++;
							//break;
						}
						cont++;
					}
					if(!variavelInvalida) {
						codigo = tokensLexico.map("INTEIRO");
						manipulandoTabela(dadosTabela, palavra, codigo);
					} else {
						System.out.println("Variavel Invalida!!!");
					}
					palavra = "";
					i = (cont + i);
					
				} 
				//caracter anterior n�o � um delimitador
				else {
					palavra += texto[i];
					int cont = 0;
					for(int j = i+1; j<texto.length; j++) {
						if(delimitador(texto[j])) {
							break;
						} else {
							palavra += texto[j];
						}
						cont++;
					}
					codigo = tokensLexico.map(palavra);
					manipulandoTabela(dadosTabela, palavra, codigo);
					palavra = "";
					i += cont;
					continue;
				}
				ultimoCaracterLetra = false;
				caracterVazio = false;
			}
			//verificando se caracter � delimitador
			if(delimitador(texto[i])) {
				
				if(texto[i].equals("_")) {
					palavra += texto[i];
					caracterVazio = false;
					continue;
				}
				
				if(!palavra.equals("") && !palavra.equals(" ")) {
					codigo = tokensLexico.map(palavra);
					manipulandoTabela(dadosTabela, palavra, codigo);
					palavra = "";
				}
				if(caracterVazio == false) {
					if(avaliarProximoCaracter) {
						if(i == texto.length-1) {
							codigo = tokensLexico.map(texto[i]);
							manipulandoTabela(dadosTabela, texto[i], codigo);
							continue;
						}
						if(texto[i+1].equals("*")) {
							i = comentario(i, texto);
							
							if(semFim) {
								continue;
							}
							i++;
							continue;
						}
						
						if(delimitador(texto[i+1])) {
							palavra += texto[i];
							palavra += texto[i+1];
							
							if(delimitador(palavra) && caracterDuplo) {
								caracterDuplo = false;
								codigo = tokensLexico.map(palavra);
								manipulandoTabela(dadosTabela, palavra, codigo);
								palavra = "";
								caracterVazio = false;
								i++;
								continue;
							}
						}
						avaliarProximoCaracter = false;
					}
					codigo = tokensLexico.map(texto[i]);
					manipulandoTabela(dadosTabela, texto[i], codigo);
				}

				palavra = "";
				caracterLetra = false;
				ultimoCaracterLetra = false;
				caracterVazio = false;
			}
			//ao encontrar ' chama o m�todo para o literal
			if(texto[i].equals("'")) {
				i = literal(i, texto);
				if(semFim) {
					continue;
				}
				codigo = tokensLexico.map("LITERAL");
				manipulandoTabela(dadosTabela, literal, codigo);
				
				caracterLetra = false;
			}
			//ao chegar ao fim do texto identifica a ultima palavra
			if(i == texto.length-1) {
				if(ultimoCaracterLetra == true && !palavra.equals(" ") && !palavra.equals("'") && !palavra.equals("")) {
					palavra += texto[i];
					codigo = tokensLexico.map(palavra);
					manipulandoTabela(dadosTabela, palavra, codigo);
					palavra = "";
				}
				caracterLetra = false;
			}
			// se o caracter for letra, continua armazenando em palavra
			if(caracterLetra) {
				palavra += texto[i];
			}
			caracterLetra = true;
			ultimoCaracterLetra = true;
		}
		return pilha;
	}
	
	//metodo comentario
	public int comentario(int i, String texto[]) {
		int j = i++;
		for(j=i; j<texto.length; j++) {
			if(j == texto.length-1) {
				JOptionPane.showMessageDialog(null, "N�o encontrou o fim do coment�rio!");
				semFim = true;
				return texto.length-1;
			}
			else if(texto[j].equals("*")) {
				if(texto[j+1].equals(")")){
					numLiteral = j++;
					return numLiteral;
				}
			}
		}
		return numLiteral;
	}
	
	//metodo para capturar o literal
	public int literal(int i, String texto[]) {
		int j = i++;
		for(j=i; j<texto.length; j++) {
			if(texto[j].equals("'")) {
				numLiteral = j++;
				return numLiteral;
			}
			else if(j == texto.length-1) {
				JOptionPane.showMessageDialog(null, "N�o encontrou o fim do literal!");
				semFim = true;
				return texto.length-1;
			}
			else {
				literal += texto[j];
			}
		}
		return numLiteral;
	}
	
	//metodo para identificar se caracter atual � um numero
	public boolean numero(String letra) {
		if(letra.equals("0") || letra.equals("1") || letra.equals("2") || letra.equals("3") || letra.equals("4") || letra.equals("5")
				|| letra.equals("6") || letra.equals("7") || letra.equals("8") || letra.equals("9")) {
			return true;
		}
	    return false;
	 }
	
	//m�todo para conferir se h� um delimitador no caracter a ser lido
	public boolean delimitador(String letra) {	
		if(letra.equals(">=") || letra.equals("<=") || letra.equals("<>") || letra.equals("..") || letra.equals(":=") ) {
			caracterDuplo = true;
		}
		if(numero(letra)) {
			return false;
		}
		
		if(letra.equals("[") || letra.equals("]") || letra.equals("(") || letra.equals(")") || letra.equals(";") ||/* letra.equals(" ")
				|| letra.equals("") || */letra.equals(",") || letra.equals(">") || letra.equals("<") || letra.equals(":") || letra.equals("+")
				|| letra.equals(".")|| letra.equals("-") || letra.equals("=") || letra.equals("$") || letra.equals("*")) {
			if(letra.equals(">") || letra.equals("<") || letra.equals(":") || letra.equals(".") || letra.equals("(")) {
				avaliarProximoCaracter = true;
			}
			return true;
		}
		
		//se n�o entrou no primeiro, nem no segundo if, significa que pode ser uma letra, mas, caso n�o seja uma letra, 
		//o caracter est� vazio com um espa�o, provavelmente.
		if(!letra.equals("A") && !letra.equals("B") && !letra.equals("C") && !letra.equals("D") && !letra.equals("E")
				&& !letra.equals("F") && !letra.equals("G") && !letra.equals("H") && !letra.equals("I") && !letra.equals("J")
				&& !letra.equals("K") && !letra.equals("L") && !letra.equals("M") && !letra.equals("N") && !letra.equals("O")
				&& !letra.equals("P") && !letra.equals("Q") && !letra.equals("R") && !letra.equals("S") && !letra.equals("T")
				&& !letra.equals("U") && !letra.equals("V") && !letra.equals("W") && !letra.equals("X") && !letra.equals("Y")
				&& !letra.equals("Z")) {
			caracterVazio = true;
			return true;
		}
		return false;
	}

	//armazena dado na tabela
	public void manipulandoTabela(DefaultTableModel dadosTabela, String palavra, int codigo) {
		if(codigo != 0) {
			String cod = Integer.toString(codigo);
			dadosTabela.addRow(new String[]{cod, palavra});
			
			//mapToken.put(palavra, codigo);

			Token token = new Token();

			token.setCodigo(codigo);
			token.setPalavra(palavra);
			
	        pilha.push(token);
		}
	}
	
}