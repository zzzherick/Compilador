package analise;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

import tabela.Categoria;
import tabela.Palavras;
import tabela.TabelaSimbolos;
import tabela.TokensLexico;
import tabela.Token;

public class AnalisadorSintatico {
	
	private boolean inicioBloco = false;
	
	private boolean varLabel = false;
	private boolean varConst = false;
	private boolean varVar = false;
	private boolean varProcedure = false;
	private boolean varBegin = false;
	private boolean varDeclarada = false;
	private boolean varParametro = false;
	private boolean atribuicao = false;
	
	private boolean adicionarNivel = false;
	
	private boolean verificarCondicao = false;
	
	private boolean verificouTokenAnt = false;
	private boolean verificouParametro = false;
	private boolean verificouProcedure = false;
	private boolean verificouIdentificador = false;
	private Token procedure = null;
	
	private String procedureVerificada = "";
	
	private Token tokenAnt = new Token(); 
	
	//private boolean nivelUm = false;
	
	private String tipo = "";
	
	//private TokensLexico tokensLexico = new TokensLexico();
	private Palavras palavras = new Palavras();
	
	private Token x = new Token();
	
	private Token temp = null;
	
	private Stack<Token> derivacao = new Stack<Token>();
	
	private Boolean derivacaoNula = false;
	
	public void ordenarPilha(Stack<Token> pilha, DefaultTableModel dadosTabelaSintatico) {
				//Token token = new Token();
				Stack<Token> pilhaOrdenada = new Stack<Token>();
				
				while(pilha.empty() == false) {
					pilhaOrdenada.push(pilha.pop());
				}
				//fa�a X ser o topo da pilha
				x.setCodigo(52);
				x.setPalavra("PROGRAMA");
				
				analisador(pilhaOrdenada, dadosTabelaSintatico);
				
	}
	public void analisador(Stack<Token> pilha, DefaultTableModel dadosTabelaSintatico) {
		Token a = new Token();
		//fa�a "a" ser o pr�ximo s�mbolo da entrada
		a = pilha.pop();
		
		do {
			
		//acessa o if ap�s o primeiro ";"
		if(inicioBloco) {
			
			//verifica a categoria que estamos lidando (label, const, var, procedure)
			classificacao(a.getCodigo());
			
			//se o Token "temp" n�o estiver nulo, ent�o trabalhamos com ele
			//"temp" s� receber� o token "a", com algumas condi��es
			if(temp != null) {				
				//se o token "a" � igual a "END", ent�o diminuimos um nivel, sendo este diferente de 0
				if(a.getCodigo() == 7) {
					if(AnaliseSemantica.getNivel() != 0) {
						AnaliseSemantica.removeNivel();
						
						//aciona o m�todo dele��o, ap�s a verifica��o da procedure
						if(verificouProcedure) {
							AnaliseSemantica.delecao();
							adicionarNivel = false;
						}
					}
				}
				//insere variaveis da categoria CONST
				if(varConst) {
					if((temp.getCodigo() != a.getCodigo()) && (a.getCodigo() == 25)) {
						temp = a;
						tipo = "INTEGER";
						varDeclarada = AnaliseSemantica.insere(temp.getPalavra(), Categoria.CONSTANTE, tipo);
					}					
				}
				//insere variaveis da categoria LABEL
				if(varLabel) {
					if((temp.getCodigo() != a.getCodigo()) && (a.getCodigo() == 25)) {
						temp = a;
						tipo = "LITERAL";
						varDeclarada = AnaliseSemantica.insere(temp.getPalavra(), Categoria.ROTULO, tipo);
					}
				}
				//insere variaveis da categoria VARIAVEL
				if(varVar) {
					if((temp.getCodigo() != a.getCodigo()) && (a.getCodigo() == 25)) {
						temp = a;
						tipo = "INTEGER";
						varDeclarada = AnaliseSemantica.insere(temp.getPalavra(), Categoria.VARIAVEL, tipo);
					}
				}
				//insere a variavel da categoria PROCEDURE
				if(varProcedure) {
					if((temp.getCodigo() != a.getCodigo()) && (a.getCodigo() == 25)) {
						//System.out.println("PROCEDURE: "+ a.getPalavra());
						temp = a;
						tipo = "INTEGER";
						
						//adiciona um nivel ao entrar na PROCEDURE
						if(adicionarNivel) {
							AnaliseSemantica.adicionaNivel();
							varProcedure = false;
						}
						adicionarNivel = true;
						varDeclarada = AnaliseSemantica.insere(temp.getPalavra(), Categoria.PROCEDURE, tipo);
						verificouProcedure = true;
					}
				}
				//trabalha o escopo de BEGIN (atribui��es, chamadas, condi��es..)
				if(varBegin) {
					//trabalha com atribui��o
					if(atribuicao) {
						//verifica a exist�ncia da variavel a receber atribui��o
						if(tokenAnt.getCodigo() == 25 && !verificouTokenAnt) {
							tokenAnt.setCodigo(AnaliseSemantica.getNivel());
							varDeclarada = AnaliseSemantica.busca(tokenAnt, null);
							verificouTokenAnt = true;
						}
						//fim da atribui��o ao achar ";"
						if(a.getCodigo() == 47) {
							atribuicao = false;
						}
						//checa o nivel da variavel e seu tipo
						if(a.getCodigo() == 25) {
							temp = a;
							varDeclarada = AnaliseSemantica.busca(temp, null);
							verificouIdentificador = true;
						}
					}
					//verifica a condicao de if, while, readln, writetln, until, case, for
					if(verificarCondicao) {
						if(a.getCodigo() == 37 || a.getCodigo() == 47 || a.getCodigo() == 10 || a.getCodigo() == 17) {
							verificarCondicao = false;
						}
						if(a.getCodigo() == 25) {
							varDeclarada = AnaliseSemantica.busca(a, null);
						}
					}
					
					switch (a.getCodigo()){
						//caso o token atual tiver codigo 38, trabalharemos com atribui��o
						case 38:
							atribuicao = true;
							break;
						//caso estivermos lidando com um identificador ser� feito determinada a��o
						case 25:
							//break caso esse identificador j� tenha sido verificado
							if(verificouIdentificador) {
								verificouIdentificador = false;
								break;
							}
							//se procedure n�o foi nula ent�o checa se seu par�metro j� foi verificado em um CALL
							if(procedure != null) {
								if(procedureVerificada.equals(procedure.getPalavra())) {
									verificouParametro = true;
								}else {
									verificouParametro = false;
								}	
							}
							//chama o m�todo CALL para checar o seu par�metro
							if(varParametro) {
								call(a);
							}
							//se o token anterior for CALL, ent�o verifica se a procedure do CALL existe e checa seu par�metro
							if(tokenAnt.getCodigo() == 11 && verificouParametro == false) {
								varParametro = true;
								
								//verifica se a procedure do CALL existe
								varDeclarada = AnaliseSemantica.busca(null, a);
								
								procedure = a;
								break;
							}
							
							break;
						case 26:
							//chama o m�todo CALL para checar o seu par�metro
							if(varParametro) {
								call(a);
							}						
							break;
						//if
						case 13:
							verificarCondicao = true;
							break;
					    //while
						case 16:
							verificarCondicao = true;
							break;
						//writeln
						case 21:
							verificarCondicao = true;
							break;
						//readln
						case 20:
							verificarCondicao = true;
							break;
						//until
						case 19:
							verificarCondicao = true;
							break;
						//case
						case 29:
							verificarCondicao = true;
							break;
						//for
						case 27:
							verificarCondicao = true;
							break;
						case 47:
							varParametro = false;
							break;
							
						default: break;
					}
					//se token "a" for diferente do "token anterior" e diferente de ":=", ent�o "token anterior" recebe "a"
					//"token anterior" servir� para checar a vari�vel que est� recebendo atribui��o
					if(a.getCodigo() != tokenAnt.getCodigo() && a.getCodigo() != 38) {
						tokenAnt = a;
					}
				}
			}
			
			//classificacao(a.getCodigo());
			
			//temp recebe "a" se alguma classifica��o for verdadeira
			if(varLabel || varConst || varVar || varBegin || varProcedure) {
				temp = a;
			}
		}
			
		//serve para n�o trabalhar com o identificador de PROGRAM
		if(a.getCodigo() == 47) {
			inicioBloco = true;
		}
		
		//verifica se X � terminal
		if((palavras.map(x.getCodigo())).getCodigo() < 52 || x.getPalavra() == "$") {
			
			//verifica se X � igual a "a"
			if((x.getCodigo() == a.getCodigo())) {
			
				//retira X do topo da pilha
				x = derivacao.pop();
				
				//retira "a" da entrada				
				a = pilha.pop();
				
			} else {
				JOptionPane.showMessageDialog(null, "ERRO! C�digo " + x.getCodigo() + " ' " + x.getPalavra() + " ' do Sint�tico n�o � igual ao c�digo " + derivacao.peek().getCodigo() + " ' " + derivacao.peek().getPalavra() + " ' do L�xico");
				String cod = Integer.toString(x.getCodigo());
				dadosTabelaSintatico.addRow(new String[]{cod + " ERRO!", x.getPalavra()});

				AnaliseSemantica.limpar();
				temp = null;
				
				return;
			}
		}
		//X n�o � um terminal
		else {
			
			if(comparador(x, a)) {
				if(derivacaoNula) {
					derivacaoNula = false;
					x = derivacao.pop();

					String cod = Integer.toString(x.getCodigo());
					dadosTabelaSintatico.addRow(new String[]{cod, x.getPalavra()});
					continue;
				}
				x = derivacao.pop();
			
			} else {
				JOptionPane.showMessageDialog(null,
						"A derivacao ["+ x.getCodigo() +", "+ a.getCodigo() +"] = ["+ x.getPalavra() +", "+ a.getPalavra() +"]\n"
								+ "n�o foi encontrada na tabela de parsing");
				
				String cod = Integer.toString(x.getCodigo());
				dadosTabelaSintatico.addRow(new String[]{cod + " ERRO! SEM DERIVACAO", x.getPalavra()});
				
				AnaliseSemantica.limpar();
				temp = null;
				
				return;
			}
		}

		
		String cod = Integer.toString(x.getCodigo());
		dadosTabelaSintatico.addRow(new String[]{cod, x.getPalavra()});
		
		}while(derivacao.empty() == false && pilha.empty() == false && varDeclarada == false);
		if(derivacao.empty()) {
			JOptionPane.showMessageDialog(null, "Compilado com sucesso!");
		}
		else {
			JOptionPane.showMessageDialog(null, "Erro na compila��o!");
		}
		//AnaliseSemantica.listar();
		AnaliseSemantica.limpar();
		temp = null;
	}
	
	//m�todo para verificar se o tipo da procedure � compativel com o par�metro 
	private void call(Token y) {
		varDeclarada = AnaliseSemantica.busca(procedure, y);
		
		verificouParametro = true;
		
		//varParametro = false;
		procedureVerificada = y.getPalavra();
	}
	
	//m�todo para classificar tokens
	private void classificacao(int a) {
		//LABEL
		if(a == 2) {
			varConst = false; varVar = false; varProcedure = false; varBegin = false;
			
			varLabel = true;
		}	
		//CONST
		else if(a == 3) {
			varVar = false; varLabel = false; varProcedure = false; varBegin = false;
			
			varConst = true;
		} 	
		//VAR
		else if(a == 4) {
			varLabel = false; varConst = false; varProcedure = false; varBegin = false;
			
			varVar = true;
		}	
		//PROCEDURE
		else if(a == 5) {
			varConst = false; varVar = false; varLabel = false; varBegin = false;
			
			varProcedure = true;
		}
		//BEGIN
		else if(a == 6) {
			varConst = false; varVar = false; varLabel = false; varProcedure = false;
			
			varBegin = true;
		}
	}
	
	public boolean comparador(Token x, Token a) {
		if(x.getCodigo() == 52 && a.getCodigo() == 1) {
			derivacao.push(palavras.map(49));
			derivacao.push(palavras.map(53));
			derivacao.push(palavras.map(47));
			derivacao.push(palavras.map(25));
			derivacao.push(palavras.map(1));
			
			return true;
		}
		
		if((x.getCodigo() == 53 && (a.getCodigo() == 2 || a.getCodigo() == 3 || a.getCodigo() == 4
				|| a.getCodigo() == 5 || a.getCodigo() == 6))) {
			derivacao.push(palavras.map(64));
			derivacao.push(palavras.map(62));
			derivacao.push(palavras.map(59));
			derivacao.push(palavras.map(57));
			derivacao.push(palavras.map(54));
			
			return true;
		}
		if((x.getCodigo() == 54 && a.getCodigo() == 2)){
			derivacao.push(palavras.map(47));
			derivacao.push(palavras.map(55));
			derivacao.push(palavras.map(2));
			
			return true;
		}
		if((x.getCodigo() == 55 && a.getCodigo() == 25)){
			derivacao.push(palavras.map(56));
			derivacao.push(palavras.map(25));
			
			return true;
		}
		if((x.getCodigo() == 56 && a.getCodigo() == 46)){
			derivacao.push(palavras.map(56));
			derivacao.push(palavras.map(25));
			derivacao.push(palavras.map(46));
			
			return true;
		}
		if((x.getCodigo() == 57 && a.getCodigo() == 3)){
			derivacao.push(palavras.map(58));
			derivacao.push(palavras.map(47));
			derivacao.push(palavras.map(26));
			derivacao.push(palavras.map(40));
			derivacao.push(palavras.map(25));
			derivacao.push(palavras.map(3));
			
			return true;
		}
		if((x.getCodigo() == 58 && a.getCodigo() == 25)){
			derivacao.push(palavras.map(58));
			derivacao.push(palavras.map(47));
			derivacao.push(palavras.map(26));
			derivacao.push(palavras.map(40));
			derivacao.push(palavras.map(25));
						
			return true;
		}
		if((x.getCodigo() == 59 && a.getCodigo() == 4)){
			derivacao.push(palavras.map(60));
			derivacao.push(palavras.map(47));
			derivacao.push(palavras.map(61));
			derivacao.push(palavras.map(39));
			derivacao.push(palavras.map(55));
			derivacao.push(palavras.map(4));
			
			return true;
		}
		if((x.getCodigo() == 60 && a.getCodigo() == 25)){
			derivacao.push(palavras.map(60));
			derivacao.push(palavras.map(47));
			derivacao.push(palavras.map(61));
			derivacao.push(palavras.map(39));
			derivacao.push(palavras.map(55));
			
			return true;
		}
		if((x.getCodigo() == 61 && a.getCodigo() == 8)){
			derivacao.push(palavras.map(8));
			
			return true;
		}
		if((x.getCodigo() == 61 && a.getCodigo() == 9)){
			derivacao.push(palavras.map(8));
			derivacao.push(palavras.map(10));
			derivacao.push(palavras.map(35));
			derivacao.push(palavras.map(26));
			derivacao.push(palavras.map(50));
			derivacao.push(palavras.map(26));
			derivacao.push(palavras.map(34));
			derivacao.push(palavras.map(9));
			
			return true;
		}
		if((x.getCodigo() == 62 && a.getCodigo() == 5)){			
			derivacao.push(palavras.map(62));
			derivacao.push(palavras.map(47));
			derivacao.push(palavras.map(53));
			derivacao.push(palavras.map(47));
			derivacao.push(palavras.map(63));
			derivacao.push(palavras.map(25));
			derivacao.push(palavras.map(5));
			
			return true;
		}
		if((x.getCodigo() == 63 && a.getCodigo() == 36)){
			derivacao.push(palavras.map(37));
			derivacao.push(palavras.map(8));
			derivacao.push(palavras.map(39));
			derivacao.push(palavras.map(55));
			derivacao.push(palavras.map(36));
			
			return true;
		}
		if((x.getCodigo() == 64 && a.getCodigo() == 6)){
			derivacao.push(palavras.map(7));
			derivacao.push(palavras.map(65));
			derivacao.push(palavras.map(66));
			derivacao.push(palavras.map(6));
			
			return true;
		}
		if((x.getCodigo() == 65 && a.getCodigo() == 47)){
			derivacao.push(palavras.map(65));
			derivacao.push(palavras.map(66));
			derivacao.push(palavras.map(47));
			
			return true;
		}
		if((x.getCodigo() == 66 && a.getCodigo() == 6)){
			derivacao.push(palavras.map(64));
			
			return true;
		}
		if((x.getCodigo() == 66 && a.getCodigo() == 11)){
			derivacao.push(palavras.map(69));
			derivacao.push(palavras.map(25));
			derivacao.push(palavras.map(11));
			
			return true;
		}
		if((x.getCodigo() == 66 && a.getCodigo() == 12)){
			derivacao.push(palavras.map(25));
			derivacao.push(palavras.map(12));
			
			return true;
		}
		if((x.getCodigo() == 66 && a.getCodigo() == 13)){
			derivacao.push(palavras.map(71));
			derivacao.push(palavras.map(66));
			derivacao.push(palavras.map(14));
			derivacao.push(palavras.map(77));
			derivacao.push(palavras.map(13));
			
			return true;
		}
		if((x.getCodigo() == 66 && a.getCodigo() == 16)){
			derivacao.push(palavras.map(66));
			derivacao.push(palavras.map(17));
			derivacao.push(palavras.map(77));
			derivacao.push(palavras.map(16));
			
			return true;
		}
		if((x.getCodigo() == 66 && a.getCodigo() == 18)){
			derivacao.push(palavras.map(77));
			derivacao.push(palavras.map(19));
			derivacao.push(palavras.map(66));
			derivacao.push(palavras.map(18));
			
			return true;
		}
		if((x.getCodigo() == 66 && a.getCodigo() == 20)){
			derivacao.push(palavras.map(37));
			derivacao.push(palavras.map(74));
			derivacao.push(palavras.map(72));
			derivacao.push(palavras.map(36));
			derivacao.push(palavras.map(20));
			
			return true;
		}
		if((x.getCodigo() == 66 && a.getCodigo() == 21)){
			derivacao.push(palavras.map(37));
			derivacao.push(palavras.map(76));
			derivacao.push(palavras.map(75));
			derivacao.push(palavras.map(36));
			derivacao.push(palavras.map(21));
			
			return true;
		}
		if((x.getCodigo() == 66 && a.getCodigo() == 25)){
			derivacao.push(palavras.map(67));
			derivacao.push(palavras.map(25));
			
			return true;
		}
		if((x.getCodigo() == 66 && a.getCodigo() == 27)){
			derivacao.push(palavras.map(66));
			derivacao.push(palavras.map(17));
			derivacao.push(palavras.map(77));
			derivacao.push(palavras.map(28));
			derivacao.push(palavras.map(77));
			derivacao.push(palavras.map(38));
			derivacao.push(palavras.map(25));
			derivacao.push(palavras.map(27));
			
			return true;
		}
		if((x.getCodigo() == 66 && a.getCodigo() == 29)){
			derivacao.push(palavras.map(7));
			derivacao.push(palavras.map(84));
			derivacao.push(palavras.map(10));
			derivacao.push(palavras.map(77));
			derivacao.push(palavras.map(29));
			
			return true;
		}
		if((x.getCodigo() == 67 && (a.getCodigo() == 38 || a.getCodigo() == 34))){
			derivacao.push(palavras.map(77));
			derivacao.push(palavras.map(38));
			derivacao.push(palavras.map(68));
			
			return true;
		}
		if((x.getCodigo() == 67 && a.getCodigo() == 39)){
			derivacao.push(palavras.map(66));
			derivacao.push(palavras.map(39));
			
			return true;
		}
		if((x.getCodigo() == 68 && a.getCodigo() == 34)){
			derivacao.push(palavras.map(35));
			derivacao.push(palavras.map(77));
			derivacao.push(palavras.map(34));
			
			return true;
		}
		if((x.getCodigo() == 69 && a.getCodigo() == 36)){
			derivacao.push(palavras.map(37));
			derivacao.push(palavras.map(70));
			derivacao.push(palavras.map(77));
			derivacao.push(palavras.map(36));
			
			return true;
		}
		if((x.getCodigo() == 70 && a.getCodigo() == 46)){
			derivacao.push(palavras.map(70));
			derivacao.push(palavras.map(77));
			derivacao.push(palavras.map(46));
			
			return true;
		}
		if((x.getCodigo() == 71 && a.getCodigo() == 15)){
			derivacao.push(palavras.map(66));
			derivacao.push(palavras.map(15));
			
			return true;
		}
		if((x.getCodigo() == 72 && a.getCodigo() == 25)){
			derivacao.push(palavras.map(73));
			derivacao.push(palavras.map(25));
			
			return true;
		}
		if((x.getCodigo() == 73 && a.getCodigo() == 34)){
			derivacao.push(palavras.map(35));
			derivacao.push(palavras.map(77));
			derivacao.push(palavras.map(34));
			
			return true;
		}
		if((x.getCodigo() == 74 && a.getCodigo() == 46)){
			derivacao.push(palavras.map(74));
			derivacao.push(palavras.map(72));
			derivacao.push(palavras.map(46));
			
			return true;
		}
		if((x.getCodigo() == 75 && (a.getCodigo() == 24 || a.getCodigo() == 25 || a.getCodigo() == 26 || a.getCodigo() == 30
				|| a.getCodigo() == 31 || a.getCodigo() == 36))){
			derivacao.push(palavras.map(77));
			
			return true;
		}
		if((x.getCodigo() == 75 && a.getCodigo() == 48)){
			derivacao.push(palavras.map(48));
			
			return true;
		}
		if((x.getCodigo() == 76 && a.getCodigo() == 46)){
			derivacao.push(palavras.map(76));
			derivacao.push(palavras.map(75));
			derivacao.push(palavras.map(46));
			
			return true;
		}
		if( (x.getCodigo() == 77 && (a.getCodigo() == 24 || a.getCodigo() == 25 || a.getCodigo() == 26
				|| a.getCodigo() == 30 || a.getCodigo() == 31 || a.getCodigo() == 36))){
			derivacao.push(palavras.map(78));
			derivacao.push(palavras.map(79));
			
			return true;
		}
		if((x.getCodigo() == 78 && a.getCodigo() == 40)){
			derivacao.push(palavras.map(79));
			derivacao.push(palavras.map(40));
			
			return true;
		}
		if((x.getCodigo() == 78 && a.getCodigo() == 41)){
			derivacao.push(palavras.map(79));
			derivacao.push(palavras.map(41));
			
			return true;
		}
		if((x.getCodigo() == 78 && a.getCodigo() == 42)){
			derivacao.push(palavras.map(79));
			derivacao.push(palavras.map(42));
			
			return true;
		}
		if((x.getCodigo() == 78 && a.getCodigo() == 43)){
			derivacao.push(palavras.map(79));
			derivacao.push(palavras.map(43));
			
			return true;
		}
		if((x.getCodigo() == 78 && a.getCodigo() == 44)){
			derivacao.push(palavras.map(79));
			derivacao.push(palavras.map(44));
			
			return true;
		}
		if((x.getCodigo() == 78 && a.getCodigo() == 45)){
			derivacao.push(palavras.map(79));
			derivacao.push(palavras.map(45));
			
			return true;
		}
		if((x.getCodigo() == 79 && (a.getCodigo() == 24 || a.getCodigo() == 25 || a.getCodigo() == 26 || a.getCodigo() == 36))){
			derivacao.push(palavras.map(80));
			derivacao.push(palavras.map(81));
			
			return true;
		}
		if((x.getCodigo() == 79 && a.getCodigo() == 30)){
			derivacao.push(palavras.map(80));
			derivacao.push(palavras.map(81));
			derivacao.push(palavras.map(30));
			
			return true;
		}
		if((x.getCodigo() == 79 && a.getCodigo() == 31)){
			derivacao.push(palavras.map(80));
			derivacao.push(palavras.map(81));
			derivacao.push(palavras.map(31));
			
			return true;
		}
		if((x.getCodigo() == 80 && a.getCodigo() == 22)){
			derivacao.push(palavras.map(80));
			derivacao.push(palavras.map(81));
			derivacao.push(palavras.map(22));
			
			return true;
		}
		if((x.getCodigo() == 80 && a.getCodigo() == 30)){
			derivacao.push(palavras.map(80));
			derivacao.push(palavras.map(81));
			derivacao.push(palavras.map(30));
			
			return true;
		}
		if((x.getCodigo() == 80 && a.getCodigo() == 31)){
			derivacao.push(palavras.map(80));
			derivacao.push(palavras.map(81));
			derivacao.push(palavras.map(31));
			
			return true;
		}
		if((x.getCodigo() == 81 && (a.getCodigo() == 24 || a.getCodigo() == 25 || a.getCodigo() == 26 || a.getCodigo() == 36))){
			derivacao.push(palavras.map(82));
			derivacao.push(palavras.map(83));
			
			return true;
		}
		if((x.getCodigo() == 82 && a.getCodigo() == 23)){
			derivacao.push(palavras.map(82));
			derivacao.push(palavras.map(83));
			derivacao.push(palavras.map(23));
			
			return true;
		}
		if((x.getCodigo() == 82 && a.getCodigo() == 32)){
			derivacao.push(palavras.map(82));
			derivacao.push(palavras.map(83));
			derivacao.push(palavras.map(32));
			
			return true;
		}
		if((x.getCodigo() == 82 && a.getCodigo() == 33)){
			derivacao.push(palavras.map(82));
			derivacao.push(palavras.map(83));
			derivacao.push(palavras.map(33));
			
			return true;
		}
		if((x.getCodigo() == 83 && a.getCodigo() == 24)){
			derivacao.push(palavras.map(83));
			derivacao.push(palavras.map(24));
			
			return true;
		}
		if((x.getCodigo() == 83 && a.getCodigo() == 25)){
			derivacao.push(palavras.map(25));
			
			return true;
		}
		if((x.getCodigo() == 83 && a.getCodigo() == 26)) {
			derivacao.push(palavras.map(26));
			
			return true;
		}
		if((x.getCodigo() == 83 && a.getCodigo() == 36)) {
			derivacao.push(palavras.map(37));
			derivacao.push(palavras.map(77));
			derivacao.push(palavras.map(36));
			
			return true;
		}
		if((x.getCodigo() == 84 && a.getCodigo() == 26)) {
			derivacao.push(palavras.map(85));
			derivacao.push(palavras.map(66));
			derivacao.push(palavras.map(39));
			derivacao.push(palavras.map(86));
			derivacao.push(palavras.map(26));
			
			return true;
		}
		if((x.getCodigo() == 85 && a.getCodigo() == 47)) {
			derivacao.push(palavras.map(84));
			derivacao.push(palavras.map(47));
			
			return true;
		}
		if((x.getCodigo() == 86 && a.getCodigo() == 46)) {
			derivacao.push(palavras.map(86));
			derivacao.push(palavras.map(26));
			derivacao.push(palavras.map(46));
			
			return true;
		}
		//deriva��es nula
		if((x.getCodigo() == 54 && (a.getCodigo() == 3 || a.getCodigo() == 4 || a.getCodigo() == 5 || a.getCodigo() == 6))
				|| (x.getCodigo() == 56 && (a.getCodigo() == 39 || a.getCodigo() == 47))
				|| (x.getCodigo() == 57 && (a.getCodigo() == 4 || a.getCodigo() == 5 || a.getCodigo() == 6))
				|| (x.getCodigo() == 58 && (a.getCodigo() == 4 || a.getCodigo() == 5 || a.getCodigo() == 6))
				|| (x.getCodigo() == 59 && (a.getCodigo() == 5 || a.getCodigo() == 6))
				|| (x.getCodigo() == 60 && (a.getCodigo() == 5 || a.getCodigo() == 6))
				|| (x.getCodigo() == 62 && a.getCodigo() == 6) || (x.getCodigo() == 63 && a.getCodigo() == 39)
				|| (x.getCodigo() == 65 && a.getCodigo() == 7) || (x.getCodigo() == 66 && (a.getCodigo() == 7
				|| a.getCodigo() == 15 || a.getCodigo() == 19 || a.getCodigo() == 47)) || (x.getCodigo() == 68 && a.getCodigo() == 38)
				|| (x.getCodigo() == 69 && (a.getCodigo() == 7 || a.getCodigo() == 15 || a.getCodigo() == 19 || a.getCodigo() == 47))
				|| (x.getCodigo() == 70 && a.getCodigo() == 37) || (x.getCodigo() == 71 && (a.getCodigo() == 7 || a.getCodigo() == 19
				|| a.getCodigo() == 47))
				|| (x.getCodigo() == 73 && (a.getCodigo() == 7 || a.getCodigo() == 10 || a.getCodigo() == 14 
				|| a.getCodigo() == 15 || a.getCodigo() == 17 || a.getCodigo() == 19 || a.getCodigo() == 22
				|| a.getCodigo() == 23 || a.getCodigo() == 28 || a.getCodigo() == 30 || a.getCodigo() == 31
				|| a.getCodigo() == 32 || a.getCodigo() == 33 || a.getCodigo() == 35 || a.getCodigo() == 37
				|| a.getCodigo() == 40 || a.getCodigo() == 41 || a.getCodigo() == 42 || a.getCodigo() == 43
				|| a.getCodigo() == 44 || a.getCodigo() == 45 || a.getCodigo() == 46 || a.getCodigo() == 47))
				|| (x.getCodigo() == 74 && a.getCodigo() == 37) || (x.getCodigo() == 76 && a.getCodigo() == 37)
				|| (x.getCodigo() == 78 && (a.getCodigo() == 7 || a.getCodigo() == 10 || a.getCodigo() == 14 
				|| a.getCodigo() == 15 || a.getCodigo() == 17 || a.getCodigo() == 19 || a.getCodigo() == 28
				|| a.getCodigo() == 35 || a.getCodigo() == 37 || a.getCodigo() == 46 || a.getCodigo() == 47))				
				|| (x.getCodigo() == 80 && (a.getCodigo() == 7 || a.getCodigo() == 10 || a.getCodigo() == 14 || a.getCodigo() == 15
				|| a.getCodigo() == 17 || a.getCodigo() == 19 || a.getCodigo() == 28 || a.getCodigo() == 35
				|| a.getCodigo() == 37 || a.getCodigo() == 40 || a.getCodigo() == 41 || a.getCodigo() == 42 || a.getCodigo() == 43
				|| a.getCodigo() == 44 || a.getCodigo() == 45 || a.getCodigo() == 46 || a.getCodigo() == 47))				
				|| (x.getCodigo() == 82 && (a.getCodigo() == 7 || a.getCodigo() == 10 || a.getCodigo() == 14 || a.getCodigo() == 15
						|| a.getCodigo() == 17 || a.getCodigo() == 19 || a.getCodigo() == 22 || a.getCodigo() == 28 || a.getCodigo() == 30
						|| a.getCodigo() == 31 || a.getCodigo() == 35 || a.getCodigo() == 37 || a.getCodigo() == 40 || a.getCodigo() == 41
						|| a.getCodigo() == 42 || a.getCodigo() == 43 || a.getCodigo() == 44 || a.getCodigo() == 45 || a.getCodigo() == 46
						|| a.getCodigo() == 47)) || (x.getCodigo() == 85 && a.getCodigo() == 7) || (x.getCodigo() == 86 && a.getCodigo() == 39)){
			derivacaoNula = true;
			return true;
		}
		return false;
	}
}

