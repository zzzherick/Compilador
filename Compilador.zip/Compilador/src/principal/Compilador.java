package principal;

import java.awt.EventQueue;
import java.awt.Insets;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import analise.AnalisadorLexico;
import analise.AnalisadorSintatico;
import tabela.Token;

import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Stack;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.event.KeyEvent;
import javax.swing.JLabel;
import java.awt.Font;

public class Compilador extends JFrame {

	private JPanel contentPane;
	private static JTextArea textArea;
	
	private JTable tabela;
	public DefaultTableModel dadosTabela = new DefaultTableModel();
	
	private JTable tabelaSintatico;
	public DefaultTableModel dadosTabelaSintatico = new DefaultTableModel();
	
	Stack<Token> pilha = new Stack<Token>();
	String texto[];
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Compilador frame = new Compilador();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public Compilador() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(320, 50, 800, 669);
		
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		JScrollPane scrollPaneTabela = new JScrollPane();
		scrollPaneTabela.setBounds(483, 331, 296, 263);
		
		JScrollPane scrollPaneCodigo = new JScrollPane();
		scrollPaneCodigo.setBounds(10, 5, 467, 589);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(483, 32, 296, 263);
		
		JTextArea textCont = new JTextArea();
		textCont.setText("1");
		textCont.setMargin(new Insets(0, 0, 0, 10));
		textCont.setForeground(Color.RED);
		scrollPaneCodigo.setRowHeaderView(textCont);
		contentPane.setLayout(null);
		contentPane.add(scrollPaneTabela);

		textArea = new JTextArea();
		textArea.addKeyListener(new KeyAdapter() {
			
			@Override
			public void keyReleased(KeyEvent arg0) {
				if(arg0.getKeyCode() == arg0.VK_ENTER) {
					contaLinhaEnter(textArea,textCont);
				}
				else if(arg0.getKeyCode() == arg0.VK_BACK_SPACE) {
					contaLinhaBack(textArea,textCont);
				}
				else if(arg0.getKeyCode() == arg0.VK_DELETE) {
					contaLinhaBack(textArea,textCont);
				}
				else if(arg0.getKeyCode() == arg0.VK_CONTROL) {
					contaLinhaBack(textArea,textCont);
				}
			}
		});
		//retunr textArea.getLineCount());
		textArea.setForeground(Color.BLACK);
		scrollPaneCodigo.setViewportView(textArea);

		tabela = new JTable(dadosTabela);
		scrollPaneTabela.setViewportView(tabela);
		dadosTabela.addColumn("Codigo");
		dadosTabela.addColumn("Palavra");
		//contentPane.setLayout(null);
		
		tabelaSintatico = new JTable(dadosTabelaSintatico);
		scrollPane.setViewportView(tabelaSintatico);
		dadosTabelaSintatico.addColumn("Codigo");
		dadosTabelaSintatico.addColumn("Palavra");
		contentPane.add(scrollPane);
		contentPane.add(scrollPaneCodigo);
		
		JLabel lblAnalisadorLxico = new JLabel("Analisador L\u00E9xico");
		lblAnalisadorLxico.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblAnalisadorLxico.setBounds(483, 306, 199, 14);
		contentPane.add(lblAnalisadorLxico);
		
		JLabel lblAnalisadorSinttico = new JLabel("Analisador Sint\u00E1tico");
		lblAnalisadorSinttico.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblAnalisadorSinttico.setBounds(483, 7, 199, 14);
		contentPane.add(lblAnalisadorSinttico);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JButton btnAbrir = new JButton("Abrir");
		btnAbrir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					textArea.setText(ler(ProcurarArq()));
					contaLinhaEnter(textArea, textCont);
				} catch (IOException e) {
					JOptionPane.showMessageDialog(null, "Erro ao ler arquivo: "+e.getMessage());
				}
			}
		});
		menuBar.add(btnAbrir);
		
		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					gravar(textArea.getText(), ProcurarArq());
					JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
				} catch (IOException e) {
					JOptionPane.showMessageDialog(null, "Erro ao salvar arquivo: "+e.getMessage());
				}
			}
		});
		menuBar.add(btnSalvar);
		
		//bot�o executar
		JButton btnExecutar = new JButton("Executar");
		btnExecutar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				texto = textArea.getText().toUpperCase().toString().split("");

				dadosTabela.setNumRows(0);
				dadosTabelaSintatico.setNumRows(0);
				
				AnalisadorLexico al = new AnalisadorLexico();
				pilha = al.separaLetra(texto, dadosTabela);

				/*
				Token token = new Token();
				while(pilha.empty() == false) {
					token = pilha.pop();
					
					System.out.println("Codigo: " + token.getCodigo() + "\tPalavra: " + token.getPalavra());
					System.out.println("");
				}
				*/
				if(pilha != null) {
					AnalisadorSintatico as = new AnalisadorSintatico();
					as.ordenarPilha(pilha, dadosTabelaSintatico);
				}
				
			}
		});
		menuBar.add(btnExecutar);
		
		JButton btnNovo = new JButton("Novo");
		btnNovo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				textArea.setText("");
				contaLinhaEnter(textArea, textCont);
				dadosTabela.setNumRows(0);
				dadosTabelaSintatico.setNumRows(0);
			}
		});
		menuBar.add(btnNovo);
	}
	
	public String ProcurarArq() throws IOException {
		JFileChooser fc = new JFileChooser();
		fc.setFileSelectionMode(JFileChooser.APPROVE_OPTION);
		fc.showOpenDialog(this);
		File selFile = fc.getSelectedFile();
		return selFile.getPath();
	}
	
	public String ler(String nomeArquivo){
        FileReader fileReader = null;
        BufferedReader bufferedReader = null;
        try {
            fileReader = new FileReader(nomeArquivo);
            bufferedReader = new BufferedReader(fileReader);
            StringBuilder sb = new StringBuilder();
            while (bufferedReader.ready()) {
                sb.append(bufferedReader.readLine());
                sb.append("\n");
            }
            return sb.toString();
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Erro ao abrir o arquivo: "+ ex.getMessage());
        } finally {
            if (bufferedReader != null) {
                try {
                    bufferedReader.close();
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(this, "Erro ao abrir o arquivo: "+ ex.getMessage());
                }
            }
            if (fileReader != null) {
                try {
                    fileReader.close();
                } catch (IOException ex) {
                    JOptionPane.showMessageDialog(this, "Erro ao abrir o arquivo: "+ ex.getMessage());
                }
            }
        }
        return null;
    }
	
	public static void gravar(String msg, String caminho) {
		try {
			FileWriter fw = new FileWriter(caminho);
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(msg+"\r\n");
			bw.flush();
			bw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
    public void contaLinhaEnter(JTextArea area,JTextArea cont) {
		String linhas ="";
		int i;
		for(i =0;i<area.getLineCount();i++) {
			linhas += i+1+"\n";
		}
		cont.setText(linhas);;
	}
	public void contaLinhaBack(JTextArea area,JTextArea cont) {
		String linhas ="";
		int i;
		for(i =1;i<area.getLineCount();i++) {
			linhas += i+"\n";
		}
		linhas += i;
		cont.setText(linhas);;
	}
}