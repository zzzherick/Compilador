package tabela;

import java.util.HashMap;
import java.util.Map;

public class TokensLexico {
	public int map(String palavra) {
		Map<String,Integer> mapTerminais; 
	    mapTerminais = new HashMap<String,Integer>();
	    
	    mapTerminais.put("PROGRAM", 1);
	    mapTerminais.put("LABEL", 2);
	    mapTerminais.put("CONST", 3);
	    mapTerminais.put("VAR", 4);
	    mapTerminais.put("PROCEDURE", 5);
	    mapTerminais.put("BEGIN", 6);
	    mapTerminais.put("END", 7);
	    mapTerminais.put("INTEGER", 8);
	    mapTerminais.put("ARRAY", 9);
	    mapTerminais.put("OF", 10);
	    mapTerminais.put("CALL", 11);
	    mapTerminais.put("GOTO", 12);
	    mapTerminais.put("IF", 13);
	    
	    mapTerminais.put("THEN", 14);
	    mapTerminais.put("ELSE", 15);
	    mapTerminais.put("WHILE", 16);
	    mapTerminais.put("DO", 17);
	    mapTerminais.put("REPEAT", 18);
	    mapTerminais.put("UNTIL", 19);
	    mapTerminais.put("READLN", 20);
	    mapTerminais.put("WRITELN", 21);
	    mapTerminais.put("OR", 22);
	    mapTerminais.put("AND", 23);
	    mapTerminais.put("NOT", 24);
	    mapTerminais.put("IDENTIFICADOR", 25);
	    mapTerminais.put("INTEIRO", 26);
	    
	    mapTerminais.put("FOR", 27);
	    mapTerminais.put("TO", 28);
	    mapTerminais.put("CASE", 29);
	    mapTerminais.put("+", 30);
	    mapTerminais.put("-", 31);
	    mapTerminais.put("*", 32);
	    mapTerminais.put("/", 33);
	    mapTerminais.put("[", 34);
	    mapTerminais.put("]", 35);
	    mapTerminais.put("(", 36);
	    mapTerminais.put(")", 37);
	    mapTerminais.put(":=", 38);
	    mapTerminais.put(":", 39);
	    
	    mapTerminais.put("=", 40);
	    mapTerminais.put(">", 41);
	    mapTerminais.put(">=", 42);
	    mapTerminais.put("<", 43);
	    mapTerminais.put("<=", 44);
	    mapTerminais.put("<>", 45);
	    mapTerminais.put(",", 46);
	    mapTerminais.put(";", 47);
	    mapTerminais.put("LITERAL", 48);
	    mapTerminais.put(".", 49);
	    mapTerminais.put("..", 50);
	    mapTerminais.put("$", 51);
	    
	    if(palavra.equals("") || palavra.equals(" ")) {
	    	return 0;
	    }
	    if(mapTerminais.containsKey(palavra)) {
		    for (Map.Entry<String, Integer> entry : mapTerminais.entrySet()) {
		    	
		        if(palavra.equals(entry.getKey())) {
		        	return entry.getValue();
		        }
		    }
	    }
	    return 25;
	}
}
