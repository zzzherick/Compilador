package tabela;

public  class TabelaSimbolos {
	private String nomeIdentificador;
	private Categoria categoria;
	private String tipo;
	private int nivel;
	
	 public TabelaSimbolos(String nomeIdentifcador, Categoria categoria, String tipo, int nivel) {
	        this.nomeIdentificador = nomeIdentifcador;
	        this.categoria = categoria;
	        this.tipo = tipo;
	        this.nivel = nivel;
	 }
	
	public String getNomeIdentificador() {
		return nomeIdentificador;
	}
	public void setNomeIdentificador(String nomeIdentificador) {
		this.nomeIdentificador = nomeIdentificador;
	}
	public Categoria getCategoria() {
		return categoria;
	}
	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	public int getNivel() {
		return nivel;
	}
	public void setNivel(int nivel) {
		this.nivel = nivel;
	}	
}
