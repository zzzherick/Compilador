package tabela;

public enum Categoria {
	VARIAVEL,
	CONSTANTE,
	PROCEDURE,
	ROTULO,
	PARAMETRO;

	public static Categoria categoria(String valor){
        if(valor.equals("VARIAVEL")){
            return VARIAVEL;
        }
        if(valor.equals("CONSTANTE")) {
        	return CONSTANTE;
        }
        if(valor.equals("PROCEDURE")) {
        	return PROCEDURE;
        }
        if(valor.equals("ROTULO")) {
        	return ROTULO;
        }
        if(valor.equals("PARAMETRO")) {
        	return PARAMETRO;
        }
        return null;
    }
}
