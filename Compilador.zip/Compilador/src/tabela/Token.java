package tabela;

public class Token {
	int codigo;
	String palavra;
	
	/*
	public Token(String palavra, int codigo) {
		this.codigo = codigo;
		this.palavra = palavra;
	}
	*/
	
	public int getCodigo() {
		return codigo;
	}
	
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	
	public String getPalavra() {
		return palavra;
	}
	
	public void setPalavra(String palavra) {
		this.palavra = palavra;
	}
}
